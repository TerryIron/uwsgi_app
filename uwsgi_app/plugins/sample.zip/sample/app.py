
class App(object):
    def __init__(self):
        self.name = 'test'

    def start(self):
        print 'App {} is started'.format(self.name)


APP = None


def init():
    global APP
    APP = App()


def start(**kwargs):
    APP.start()
