#!/usr/bin/env python                                                                                                                                                             
# -*- coding: utf-8 -*-


class Application(object):
    import logging

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def set_logger(self, logger):
        self.logger = logger


APP = None
CONFIG = {}


def init():
    global APP
    APP = Application()
    CONFIG['logger.path'] = '/tmp/sample.log'


def start(loader, **kwargs):
    pass


def stop(loader, **kwargs):
    pass
