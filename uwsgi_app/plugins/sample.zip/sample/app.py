class App(object):
    def __init__(self):
        self.name = 'test'

    def start(self):
        pass


APP = None


def init():
    global APP
    APP = App()


def start(loader, **kwargs):
    loader.logger.info('start')
    loader.logger.info(loader.config)
    loader.logger.info(loader.channel)
    loader.logger.info(loader.channel_scope)
    loader.logger.info(kwargs)
    APP.start()
    return {'result': 'hello world', 'data': ''}
