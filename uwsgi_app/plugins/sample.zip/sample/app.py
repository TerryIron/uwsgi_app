class App(object):
    def __init__(self):
        self.name = 'test'

    def start(self):
        pass


APP = None


def init():
    global APP
    APP = App()


def start(loader, **kwargs):
    loader.log.info('start')
    loader.log.info(loader.config)
    loader.log.info(kwargs)
    APP.start()
    return {'hello': 'world'}
