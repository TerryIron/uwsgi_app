
class App(object):
    def __init__(self):
        self.name = 'test'

    def start(self):
        print 'App {} is started'.format(self.name)


def start(**kwargs):
    a = App()
    a.start()
